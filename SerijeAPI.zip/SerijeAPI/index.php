<?php
require 'vendor/autoload.php';
require 'bootstrap.php';
use Neretljak\Serija;
use Neretljak\Projekt;
use Composer\Autoload\ClassLoader;

Flight::route('/', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20202021/aneretljak_20/ontologija/serije.rdf');
  $info = $foaf->dump();
  echo "<h2>Ontologija za P3 zadatak:</h2> <br/><br/>" . $info;
});



Flight::route('GET /search', function(){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Neretljak\Serija');
  $zapisi = $repozitorij->findAll();
  echo $doctrineBootstrap->getJson($zapisi);
});

Flight::route('GET /ucitaj', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20202021/aneretljak_20/ontologija/serije.rdf');
  foreach ($foaf->resources() as $resource) {

    $name = $foaf->get($resource, 'foaf:name');

    if($name != ''){

      $i = 0;
      $annotations = "";

      
      $description = $foaf->get($resource, 'dc11:description'); 
      $comment = $foaf->get($resource, 'rdfs:comment');
      $subject = $foaf->get($resource, 'dc11:subject');

      foreach ($resource->properties() as $key) {
          $annotations .= $key . ': ' . $foaf->get($resource, $key) . "\n"; 
      }

      $serija = new Serija();
      $serija->setPodaci(Flight::request()->data);

      $serija->setNaziv($name); 
      $serija->setOcjena($description); 
      $serija->setEpizode($comment);
      $serija->setZanr($subject);
      $serija->setSveAnotacije($annotations);

      $doctrineBootstrap = Flight::entityManager();
      $em = $doctrineBootstrap->getEntityManager();

      $em->persist($serija);
      $em->flush();

    
    }
  }

  echo "U bazu je uspješno unijeta ontologija.";

});

Flight::route('GET /search/@name', function($name){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Neretljak\Serija');
  $zapisi = $repozitorij->createQueryBuilder('p')
                        ->where('p.naziv LIKE :naziv')
                        ->setParameter('naziv', '%'.$name.'%')
                        ->getQuery()
                        ->getResult();  
  echo $doctrineBootstrap->getJson($zapisi);

});

$cl = new ClassLoader('Neretljak', __DIR__, '/src');
$cl->register();
require_once 'bootstrap.php';
Flight::register('entityManager', 'DoctrineBootstrap');

Flight::start();

