create database aneretljak_20_20 default character set utf8;
use aneretljak_20_20;
create table serija(
    sifra int not null primary key auto_increment,
    naziv varchar(255) not null,
    ocjena varchar(100) not null,
    epizode varchar(500) not null,
    zanr varchar(255) not null,
    sveAnotacije varchar(255) not null
);

insert into serija(naziv, ocjena, epizode, zanr, sveAnotacije) 
values ("Test", "Test", "2", "Test", "Test");