<?php

namespace Neretljak;

/**
 * @Entity @Table(name="serija")
 **/


class Serija
{
    /** @id @Column(type="integer") @GeneratedValue **/
    protected $sifra;

    /**
    * @Column(type="string")
    */
    private $naziv;

     /**
    * @Column(type="string")
    */
    private $ocjena;

    /**
    * @Column(type="string")
    */
    private $epizode;

     /**
    * @Column(type="string")
    */
    private $zanr; 

  /**
    * @Column(type="string")
    */
    private $sveAnotacije;

    public function getSifra(){
      return $this->sifra;
    }
  
    public function setSifra($sifra){
      $this->sifra = $sifra;
    }
  
    public function getNaziv(){
      return $this->naziv;
    }
  
    public function setNaziv($naziv){
      $this->naziv = $naziv;
    }
  
    public function getOcjena(){
      return $this->ocjena;
    }
  
    public function setOcjena($ocjena){
      $this->ocjena = $ocjena;
    }
  
    public function getEpizode(){
      return $this->epizode;
    }
  
    public function setEpizode($epizode){
      $this->epizode = $epizode;
    }
  
    public function getZanr(){
      return $this->zanr;
    }
  
    public function setZanr($zanr){
      $this->zanr = $zanr;
    }

    public function getSveAnotacije(){
      return $this->sveAnotacije;
    }
  
    public function setSveAnotacije($sveAnotacije){
      $this->sveAnotacije = $sveAnotacije;
    }

    
    
  public function setPodaci($podaci)
	{
		foreach($podaci as $kljuc => $vrijednost){
			$this->{$kljuc} = $vrijednost;
		}
	}

}



?>
